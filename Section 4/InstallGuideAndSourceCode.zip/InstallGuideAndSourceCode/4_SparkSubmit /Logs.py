
from pyspark import SparkConf, SparkContext

conf=SparkConf().setMaster("yarn-client").setAppName("My App")
sc=SparkContext(conf=conf)

logsPath="hdfs:///user/swethakolalapudi/log/hbase.log"

logs=sc.textFile(logsPath)

errCount=sc.accumulator(0)

def processLog(line):
    global errCount
    dateField=line[:24]
    logField=line[24:]
    # some other processing
    if "ERROR" in line:
        errCount+=1
    return (dateField,logField)

logs.map(processLog).saveAsTextFile("hdfs:///user/swethakolalapudi/log/pLogsv2.log")

print "There were " + str(errCount.value)+" ERROR lines"






