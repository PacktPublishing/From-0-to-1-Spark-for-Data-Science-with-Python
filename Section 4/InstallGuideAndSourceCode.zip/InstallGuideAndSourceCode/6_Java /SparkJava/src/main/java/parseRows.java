
import org.apache.commons.lang.StringUtils;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFunction;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.List;

public class parseRows {
    public static void main(String[] args) throws Exception {

        //Setting up the SparkContext
        SparkConf conf = new SparkConf().setAppName("parseRows");
        JavaSparkContext sc = new JavaSparkContext(conf);

        //Loading the data from airports file
        JavaRDD<String> airports = sc.textFile("hdfs:///user/swethakolalapudi/flightDelaysData/airports.csv");


        //The function that will be passed to filter
        class NotHeader implements Function<String,Boolean> {
            public NotHeader() {
            }

            public Boolean call(String s) throws Exception {
                return !s.contains("Description");
            }
        }

        //Filter transformation
        JavaRDD<String> airportsFiltered = airports.filter(new NotHeader());


        //Map transformation
        JavaRDD<List<String>> airportsParsed = airportsFiltered.map(new Function<String, List<String>>() {
            public List<String> call(String s) throws Exception {
                List<String> parsedRow = new ArrayList<String>();
                parsedRow.add(s.substring(0,s.indexOf(",")).replace("\"",""));
                parsedRow.add(s.substring(s.indexOf(",")+1,s.length()-1).replace("\"",""));
                return parsedRow;
            }
        });

        //Lambda function
        JavaRDD<Integer> rowLengths = airportsFiltered.map(s -> s.length());

        //Print out the results
        for (List<String> s:airportsParsed.collect()){
            System.out.println(StringUtils.join(s, "|"));
        }


        //A Pair function - used to create Pair RDDs
        PairFunction<List<String>,String,String> arrayToPair = new PairFunction<List<String>, String, String>() {
            @Override
            public Tuple2<String, String> call(List<String> strings) throws Exception {
                return new Tuple2<>(strings.get(0),strings.get(1));
            }
        };

        //Create a Pair RDD from airports
        JavaPairRDD<String,String> airportsLookup = airportsParsed.mapToPair(arrayToPair);

        //Use it to lookup a particular airport description
        System.out.println(airportsLookup.lookup("PPG"));

    }

}
